# Quick Start

```pawn
#include <YSI_Server\y_scriptinit>

public OnScriptInit()
{
	// Called at the start, in both gamemodes and filterscripts.
}
```

